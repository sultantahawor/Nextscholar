# Next Scholar Education Consultancy Website

A responsive static website for Next Scholar Education Consultancy.

## Upload to GitHub

1. Create a new GitHub repository, e.g. `next-scholar-website`.
2. Upload all files and folders from this project.
3. Open `index.html` to preview after deployment.

## Important before publishing

Open `index.html` and replace:

`https://forms.google.com/`

with your actual Google Form URL in every Apply / Get Information button.

The WhatsApp number is not displayed as visible text. The website uses a WhatsApp click-to-chat link and QR code.

## Deploy

This is a static website, so it can be deployed using GitHub Pages, Netlify, Vercel, or most standard hosting services.

## Brand

The supplied Next Scholar logo is included at:

`assets/next-scholar-logo.jpeg`

The website theme uses navy blue, teal, white and dark gray to match the logo.

## Contact

Facebook:
https://www.facebook.com/profile.php?id=61580608773571

WhatsApp:
https://wa.me/821048972939
