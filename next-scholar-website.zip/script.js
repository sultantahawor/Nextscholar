const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".nav");

if (menuToggle && nav) {
  menuToggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
  });
  nav.querySelectorAll("a").forEach(link => {
    link.addEventListener("click", () => nav.classList.remove("open"));
  });
}

document.getElementById("year").textContent = new Date().getFullYear();

/*
  IMPORTANT:
  1. Replace every https://forms.google.com/ link in index.html with YOUR real Google Form URL.
  2. The WhatsApp number is intentionally not printed as visible text.
  3. WhatsApp links use the international format 821048972939.
*/
